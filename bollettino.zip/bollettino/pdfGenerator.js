/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║         pdfGenerator.js — Meteomont VDA                         ║
 * ║  Modulo PDF per bollettino valanghe Valle d'Aosta                ║
 * ║  Dipendenze: html2canvas, jsPDF (caricati nel HTML)              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

const PdfGenerator = (() => {

    const PAGE_W = 210;
    const PAGE_H = 297;
    const MARGIN = 14;
    const CONTENT_W = PAGE_W - MARGIN * 2;

    const DANGER_COLORS = {
        0: '#cccccc',
        1: '#4CAF50',
        2: '#FFEB3B',
        3: '#FF9800',
        4: '#f44336',
        5: '#1a0000'   
    };

    const DANGER_LABELS = {
        0: 'Nessun dato',
        1: 'Grado 1 — Debole',
        2: 'Grado 2 — Limitato',
        3: 'Grado 3 — Marcato',
        4: 'Grado 4 — Forte',
        5: 'Grado 5 — Molto Forte'
    };

    const PROBLEMI_INFO = {
        '0':            'Nessuno',
        'nevefresca':   'Neve Fresca',
        'neveventata':  'Neve Ventata',
        'stratideboli': 'Strati Deboli Persistenti',
        'nevebagnata':  'Neve Bagnata',
        'slittamento':  'Valanghe Di Slittamento'
    };

    const ICONE_EXTRA_INFO = {
        '0':           '',
        'mont_piena':  'Montagna Piena',
        'base_vuota':  'Base Vuota',
        'punta_vuota': 'Punta Vuota',
        'punta_piena': 'Punta Piena'
    };

    const DIREZIONI = ['N','NE','E','SE','S','SO','O','NO'];

    const NOME_TO_CSS_VAR = {
        'Monte Bianco':     'courmayeur',
        'La Thuile':        'la_thuile',
        'Valgrisenche':     'valgrisenche',
        'Val di Rhemes':    'val_di_Rhemes',
        'Valsavarenche':    'valsavarenche',
        'Val di Cogne':     'val_di_Cogne',
        'Pila':             'pila',
        'Mont Avic':        'mont_avic',
        'Champorcher':      'champorcher',
        'Morgex':           'morgex',
        'Mont Fallère':     'mont_fallere',
        'Gran San Bernardo':'gran_saint_bernard',
        'Valpelline':       'valpelline',
        'Becca di Viou':    'becca_di_Viou',
        'Saint Barthelemy': 'saint_barthelemy',
        'Valtournenche':    'valtournenche',
        "Val D'Ayas":       'val_d_ayas',
        'Gressoney':        'gressoney',
        'Zerbion':          'monte_zerbion'
    };

    function readBollettinoData() {
        try {
            const raw = localStorage.getItem('vda_meteo_data');
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            console.warn('[PdfGenerator] Impossibile leggere vda_meteo_data:', e);
            return [];
        }
    }

    function readNote() {
        try {
            return localStorage.getItem('vda_meteo_note') || '';
        } catch (e) {
            return '';
        }
    }

    function getCurrentData() {
        if (typeof window.zonesData !== 'undefined') {
            return window.zonesData;
        }
        return readBollettinoData();
    }

    function getCurrentNote() {
        const el = document.getElementById('note-libere');
        if (el) return el.value;
        return readNote();
    }

    function buildMapSvgMarkup(highlightId, data) {
        const svgEl = document.querySelector('.mappa-container svg');
        if (!svgEl) {
            console.warn('[PdfGenerator] SVG mappa non trovato nel DOM.');
            return null;
        }

        const clone = svgEl.cloneNode(true);
        clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        clone.querySelectorAll('image').forEach(el => el.remove());
        clone.removeAttribute('style');

        const svgIdToNome = {};
        Object.entries(NOME_TO_CSS_VAR).forEach(([nome, cssPrefix]) => {
            svgIdToNome[cssPrefix] = nome;
        });
        svgIdToNome['courmayeur']         = 'Monte Bianco';
        svgIdToNome['monte_zerbion']      = 'Zerbion';
        svgIdToNome['gran_saint_bernard'] = 'Gran San Bernardo';

        const dataByNome = {};
        data.forEach(z => { dataByNome[z.nome] = z; });

        const vbOrig = svgEl.viewBox.baseVal;

        if (highlightId) {
            const origPath = svgEl.querySelector('[id="' + highlightId + '"]');
            let vbX = vbOrig.x, vbY = vbOrig.y, vbW = vbOrig.width, vbH = vbOrig.height;

            if (origPath) {
                try {
                    const svgRect  = svgEl.getBoundingClientRect();
                    const pathRect = origPath.getBoundingClientRect();

                    if (svgRect.width > 0 && svgRect.height > 0) {
                        const scaleX = vbOrig.width  / svgRect.width;
                        const scaleY = vbOrig.height / svgRect.height;
                        const pad = Math.max(
                            pathRect.width  * scaleX,
                            pathRect.height * scaleY
                        ) * 0.35;

                        vbX = vbOrig.x + (pathRect.left - svgRect.left) * scaleX - pad;
                        vbY = vbOrig.y + (pathRect.top  - svgRect.top)  * scaleY - pad;
                        vbW = pathRect.width  * scaleX + pad * 2;
                        vbH = pathRect.height * scaleY + pad * 2;
                    }
                } catch (e) {}
            }

            clone.setAttribute('viewBox', `${vbX} ${vbY} ${vbW} ${vbH}`);
            clone.setAttribute('width',  '100%');
            clone.setAttribute('height', '300');

            const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            bg.setAttribute('x', String(vbX)); bg.setAttribute('y', String(vbY));
            bg.setAttribute('width', String(vbW)); bg.setAttribute('height', String(vbH));
            bg.setAttribute('fill', '#f0f4f8');
            clone.insertBefore(bg, clone.firstChild);

            clone.querySelectorAll('path[id]').forEach(path => {
                const id = path.getAttribute('id');
                if (id !== highlightId) {
                    path.setAttribute('display', 'none');
                } else {
                    const nome = svgIdToNome[id];
                    const zona = nome ? dataByNome[nome] : null;
                    const color = zona
                        ? (zona.danger === 5 ? '#7f1d1d' : (DANGER_COLORS[zona.danger] || '#cccccc'))
                        : '#cccccc';
                    path.setAttribute('fill',         color);
                    path.setAttribute('fill-opacity', '1');
                    path.setAttribute('stroke',       '#1e3a8a');
                    path.setAttribute('stroke-width', '8');
                }
            });

        } else {
            clone.setAttribute('width',  '100%');
            clone.setAttribute('height', '480');

            const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            bg.setAttribute('x',      String(vbOrig.x));
            bg.setAttribute('y',      String(vbOrig.y));
            bg.setAttribute('width',  String(vbOrig.width));
            bg.setAttribute('height', String(vbOrig.height));
            bg.setAttribute('fill', '#dce8f0');
            clone.insertBefore(bg, clone.firstChild);

            clone.querySelectorAll('path[id]').forEach(path => {
                const id   = path.getAttribute('id');
                const nome = svgIdToNome[id];
                const zona = nome ? dataByNome[nome] : null;
                if (zona) {
                    const isDeath = zona.danger === 5;
                    path.setAttribute('fill', isDeath ? '#7f1d1d' : (DANGER_COLORS[zona.danger] || '#cccccc'));
                    path.setAttribute('fill-opacity', '0.9');
                    path.setAttribute('stroke',       '#ffffff');
                    path.setAttribute('stroke-width', '3');
                } else {
                    path.setAttribute('fill',         '#b0bec5');
                    path.setAttribute('fill-opacity', '0.55');
                    path.setAttribute('stroke',       '#90a4ae');
                    path.setAttribute('stroke-width', '2');
                }
            });
        }

        return new XMLSerializer().serializeToString(clone);
    }

    function buildMountainSvg(zona) {
        const percent  = Math.max(0, Math.min(1, (zona.altitude - 500) / 3500));
        const splitY   = 190 - (percent * 170);
        const splitXL  = 10  + (percent * 90);
        const splitXR  = 190 - (percent * 90);

        const colorAlto  = zona.fasce[0] === 'DEATH' ? '#7f1d1d' : (zona.fasce[0] || '#ffffff');
        const colorBasso = zona.fasce[1] === 'DEATH' ? '#7f1d1d' : (zona.fasce[1] || '#ffffff');

        const dAlto  = `M 100 20 L ${splitXR} ${splitY} L ${splitXL} ${splitY} Z`;
        const dBasso = `M ${splitXL} ${splitY} L ${splitXR} ${splitY} L 190 190 L 10 190 Z`;

        return `
        <svg viewBox="0 0 200 200" width="100" height="100"
             style="border:1px solid #e2e8f0;border-radius:8px;display:block;">
            <path d="${dAlto}"  fill="${colorAlto}"  stroke="#333" stroke-width="1.5"/>
            <path d="${dBasso}" fill="${colorBasso}" stroke="#333" stroke-width="1.5"/>
            <line x1="${splitXL}" y1="${splitY}" x2="${splitXR}" y2="${splitY}"
                  stroke="#555" stroke-width="1" stroke-dasharray="4,3"/>
            <text x="100" y="${splitY - 6}" text-anchor="middle"
                  font-family="sans-serif" font-size="10" fill="#555"
                  font-weight="600">${zona.altitude}m</text>
        </svg>`;
    }

    function buildRosaVentiSvg(esposizioni) {
        const direzioni = [0, 45, 90, 135, 180, 225, 270, 315];
        const punte = direzioni.map((deg, i) => {
            const attiva = esposizioni.includes(i);
            return `<g transform="rotate(${deg} 100 100)">
                <path d="M 100,100 L 100,20 L 90,80 Z"
                      fill="${attiva ? '#1e293b' : '#cccccc'}"
                      stroke="#333" stroke-width="0.5"/>
                <path d="M 100,100 L 100,20 L 110,80 Z"
                      fill="${attiva ? '#1e293b' : '#ffffff'}"
                      stroke="#333" stroke-width="0.5"/>
            </g>`;
        }).join('');

        return `
        <svg viewBox="-55 -55 310 310" width="80" height="80" style="flex-shrink:0;">
            ${punte}
            <text x="100" y="5"   text-anchor="middle" font-family="sans-serif"
                  font-size="22" font-weight="800" fill="#dc2626">N</text>
            <text x="225" y="108" text-anchor="middle" font-family="sans-serif"
                  font-size="18" font-weight="700" fill="#64748b">E</text>
            <text x="100" y="225" text-anchor="middle" font-family="sans-serif"
                  font-size="18" font-weight="700" fill="#64748b">S</text>
            <text x="-25" y="108" text-anchor="middle" font-family="sans-serif"
                  font-size="18" font-weight="700" fill="#64748b">O</text>
        </svg>`;
    }

    function injectHiddenTemplate(html, id = 'pdf-template-hidden') {
        const existing = document.getElementById(id);
        if (existing) existing.remove();

        const wrapper = document.createElement('div');
        wrapper.id = id;
        wrapper.style.cssText = `
            position: fixed;
            top: -9999px;
            left: -9999px;
            width: 794px;
            background: #ffffff;
            font-family: ui-sans-serif, system-ui, sans-serif;
            color: #1e293b;
            padding: 0;
            z-index: -1;
            pointer-events: none;
        `;
        wrapper.innerHTML = html;
        document.body.appendChild(wrapper);
        return wrapper;
    }

    function buildZoneTemplate(zona, svgMapString, note) {
        const dangerColor   = DANGER_COLORS[zona.danger] || '#ccc';
        const dangerLabel   = DANGER_LABELS[zona.danger] || 'N/D';
        const isDeath       = zona.danger === 5;
        const badgeBg       = isDeath
            ? 'background:linear-gradient(135deg,#000,#7f1d1d);color:#ff3333;border:2px solid #ff3333;'
            : `background:${dangerColor};color:${zona.danger === 2 ? '#333' : '#fff'};`;

        const mountainSvg = buildMountainSvg(zona);

        const slotsAttivi = zona.slots.filter(s => s.problema !== '0');
        let problemHtml = '';
        if (slotsAttivi.length > 0) {
            problemHtml = slotsAttivi.map((slot, i) => {
                const probText  = PROBLEMI_INFO[slot.problema] || slot.problema;
                const extraText = ICONE_EXTRA_INFO[slot.iconaExtra] || '';
                const rosaHtml  = buildRosaVentiSvg(slot.esposizioni || []);
                const espLabels = (slot.esposizioni || []).map(e => DIREZIONI[e]).join(', ') || '—';

                return `
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;
                             padding:12px 16px;margin-bottom:10px;display:flex;
                             align-items:flex-start;gap:16px;">
                    <div style="flex:1;">
                        <div style="font-size:9px;font-weight:700;color:#6366f1;
                                    text-transform:uppercase;letter-spacing:.06em;
                                    margin-bottom:6px;">Problema ${i + 1}</div>
                        <div style="font-size:13px;font-weight:700;color:#1e293b;
                                    margin-bottom:4px;">📋 ${probText}</div>
                        ${extraText ? `<div style="font-size:11px;color:#555;
                                           margin-bottom:4px;">🏔 ${extraText}</div>` : ''}
                        ${slot.quotaLibera ? `<div style="font-size:11px;color:#3b82f6;
                                                  font-weight:700;">📈 Quota critica: ${slot.quotaLibera}</div>` : ''}
                        <div style="font-size:10px;color:#64748b;margin-top:4px;">
                            🧭 Esposizioni: <strong>${espLabels}</strong>
                        </div>
                    </div>
                    <div style="display:flex;flex-direction:column;align-items:center;gap:2px;">
                        ${rosaHtml}
                        <span style="font-size:9px;color:#94a3b8;font-weight:600;">ESPOSIZIONI</span>
                    </div>
                </div>`;
            }).join('');
        } else {
            problemHtml = `<p style="font-size:11px;color:#94a3b8;font-style:italic;
                               padding:8px 0;border-top:1px solid #f1f5f9;">
                               Nessun problema valanghivo segnalato.</p>`;
        }

        // Fix Reference Error: Utilizziamo correttamente svgMapString
        const mapSection = svgMapString ? `
        <div style="margin-top:20px;">
            <div style="font-size:10px;font-weight:700;text-transform:uppercase;
                        color:#64748b;letter-spacing:.08em;margin-bottom:8px;text-align:center;">
                📍 Mappa Zona
            </div>
            <div style="text-align:center;background:#f0f4f8;border-radius:12px;
                        padding:12px;overflow:hidden;border:1px solid #e2e8f0;max-width:400px;margin:0 auto;">
                ${svgMapString}
            </div>
        </div>` : '';

        const noteSection = note ? `
        <div style="margin-top:20px;background:#fffbeb;border:1px solid #fcd34d;
                    border-radius:10px;padding:14px 16px;">
            <div style="font-size:10px;font-weight:700;text-transform:uppercase;
                        color:#92400e;letter-spacing:.08em;margin-bottom:6px;">
                📝 Note Generali Bollettino
            </div>
            <p style="font-size:12px;color:#78350f;line-height:1.6;
                      white-space:pre-wrap;word-break:break-word;overflow-wrap:break-word;
                      margin:0;">${escapeHtml(note)}</p>
        </div>` : '';

        return `
        <div style="padding:32px 36px;min-height:297mm;box-sizing:border-box;">

            <div style="display:flex;justify-content:space-between;align-items:center;
                        border-bottom:3px solid #1e3a8a;padding-bottom:16px;margin-bottom:20px;">
                <div>
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;
                                color:#64748b;letter-spacing:.1em;">METEOMONT CIVILE</div>
                    <div style="font-size:22px;font-weight:900;color:#1e3a8a;
                                font-style:italic;text-transform:uppercase;
                                letter-spacing:-.02em;">Valle d'Aosta</div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:9px;font-weight:700;color:#94a3b8;
                                text-transform:uppercase;">Bollettino Valanghe</div>
                    <div style="font-size:10px;font-weight:700;color:#475569;">
                        ${new Date().toLocaleDateString('it-IT', {
                            weekday:'long', year:'numeric', month:'long', day:'numeric'
                        })}
                    </div>
                </div>
            </div>

            <div style="margin-bottom:20px;text-align:center;">
                <div style="font-size:9px;font-weight:700;text-transform:uppercase;
                            color:#64748b;letter-spacing:.1em;margin-bottom:4px;">
                    Settore ${zona.id} di 19
                </div>
                <h1 style="font-size:28px;font-weight:900;color:#1e3a8a;
                           font-style:italic;text-transform:uppercase;
                           margin:0 0 12px 0;">${zona.nome}</h1>

                <div style="display:inline-block;padding:6px 18px;border-radius:20px;
                            font-weight:900;font-size:12px;text-transform:uppercase;
                            letter-spacing:.07em;${badgeBg}">
                    ⚠ ${dangerLabel}
                </div>
            </div>

            <div style="display:flex;align-items:center;justify-content:center;gap:20px;margin-bottom:20px;
                        background:#f8fafc;border-radius:12px;padding:16px;">
                <div style="display:flex;flex-direction:column;align-items:center;">
                    ${mountainSvg}
                </div>
                <div>
                    <table style="border-collapse:collapse;font-size:12px;">
                        <tr>
                            <td style="padding:6px 12px 6px 0;color:#64748b;font-weight:600;">
                                🏔 Quota neve
                            </td>
                            <td style="padding:6px 0;font-weight:700;color:#1e293b;">
                                ${zona.altitude} m
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:6px 12px 6px 0;color:#64748b;font-weight:600;">
                                🔼 Parte Alta
                            </td>
                            <td style="padding:6px 0;">
                                <span style="display:inline-block;padding:2px 10px;
                                    border-radius:10px;font-size:10px;font-weight:700;
                                    background:${zona.fasce[0] === 'DEATH' ? '#7f1d1d' : (zona.fasce[0] || '#ccc')};
                                    color:${zona.fasce[0] === '#FFEB3B' ? '#333' : '#fff'};">
                                    ${fasciaTxt(zona.fasce[0])}
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:6px 12px 6px 0;color:#64748b;font-weight:600;">
                                🔽 Parte Bassa
                            </td>
                            <td style="padding:6px 0;">
                                <span style="display:inline-block;padding:2px 10px;
                                    border-radius:10px;font-size:10px;font-weight:700;
                                    background:${zona.fasce[1] === 'DEATH' ? '#7f1d1d' : (zona.fasce[1] || '#ccc')};
                                    color:${zona.fasce[1] === '#FFEB3B' ? '#333' : '#fff'};">
                                    ${fasciaTxt(zona.fasce[1])}
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div style="margin-bottom:20px;">
                <div style="font-size:10px;font-weight:700;text-transform:uppercase;
                            color:#64748b;letter-spacing:.08em;
                            border-bottom:1px solid #e2e8f0;padding-bottom:6px;
                            margin-bottom:12px;">
                    🔴 Problemi Valanghivi
                </div>
                ${problemHtml}
            </div>

            ${mapSection}
            ${noteSection}

            <div style="margin-top:24px;padding-top:12px;border-top:1px solid #e2e8f0;
                        display:flex;justify-content:space-between;
                        font-size:9px;color:#94a3b8;">
                <span>Meteomont Civile — Valle d'Aosta</span>
                <span>Comando Truppe Alpine</span>
            </div>
        </div>`;
    }

    function buildFullTemplate(data, mapImageUrl, note) {

        const noteSection = note ? `
        <div style="margin-top:24px;background:#fffbeb;border:1px solid #fcd34d;
                    border-radius:10px;padding:14px 16px;">
            <div style="font-size:10px;font-weight:700;text-transform:uppercase;
                        color:#92400e;letter-spacing:.08em;margin-bottom:6px;">
                📝 Note Generali Bollettino
            </div>
            <p style="font-size:12px;color:#78350f;line-height:1.6;
                      white-space:pre-wrap;word-break:break-word;overflow-wrap:break-word;
                      margin:0;">${escapeHtml(note)}</p>
        </div>` : '';

        return `
        <div style="padding:32px 36px;box-sizing:border-box;">

            <div style="display:flex;justify-content:space-between;align-items:center;
                        border-bottom:3px solid #1e3a8a;padding-bottom:16px;margin-bottom:24px;">
                <div>
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;
                                color:#64748b;letter-spacing:.1em;">METEOMONT CIVILE</div>
                    <div style="font-size:24px;font-weight:900;color:#1e3a8a;
                                font-style:italic;text-transform:uppercase;">
                        Valle d'Aosta — Bollettino Completo
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:9px;font-weight:700;color:#94a3b8;
                                text-transform:uppercase;">Bollettino Valanghe</div>
                    <div style="font-size:10px;font-weight:700;color:#475569;">
                        ${new Date().toLocaleDateString('it-IT', {
                            weekday:'long', year:'numeric', month:'long', day:'numeric'
                        })}
                    </div>
                </div>
            </div>

            ${mapImageUrl ? `
            <div style="margin-bottom:24px;text-align:center;">
                <div style="font-size:10px;font-weight:700;text-transform:uppercase;
                            color:#64748b;letter-spacing:.08em;margin-bottom:10px;">
                    📍 Mappa Completa Settori Valle d'Aosta
                </div>
                <div style="background:#dce8f0;border-radius:14px;
                            padding:16px;overflow:hidden;border:1px solid #e2e8f0;">
                    ${mapImageUrl}
                </div>
            </div>` : ''}

            ${noteSection}

            <div style="margin-top:24px;padding-top:12px;border-top:1px solid #e2e8f0;
                        display:flex;justify-content:space-between;
                        font-size:9px;color:#94a3b8;">
                <span>Meteomont Civile — Valle d'Aosta</span>
                <span>Comando Truppe Alpine</span>
            </div>
        </div>`;
    }

    function fasciaTxt(colore) {
        const map = {
            '#ffffff': 'Nessuno',
            '#4CAF50': 'Grado 1',
            '#FFEB3B': 'Grado 2',
            '#FF9800': 'Grado 3',
            '#f44336': 'Grado 4',
            'DEATH':   'Grado 5'
        };
        return map[colore] || 'N/D';
    }

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function toggleLoadingOverlay(show, msg = 'Generazione PDF in corso…') {
        let overlay = document.getElementById('pdf-loading-overlay');
        if (show) {
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'pdf-loading-overlay';
                overlay.style.cssText = `
                    position:fixed;inset:0;background:rgba(15,23,42,0.75);
                    display:flex;flex-direction:column;align-items:center;
                    justify-content:center;z-index:9999;color:#fff;
                    font-family:ui-sans-serif,system-ui,sans-serif;gap:12px;`;
                overlay.innerHTML = `
                    <div style="width:48px;height:48px;border:4px solid #3b82f6;
                                border-top-color:transparent;border-radius:50%;
                                animation:pdf-spin .8s linear infinite;"></div>
                    <div style="font-size:14px;font-weight:700;letter-spacing:.05em;">${msg}</div>
                    <style>@keyframes pdf-spin{to{transform:rotate(360deg)}}</style>`;
                document.body.appendChild(overlay);
            }
        } else {
            if (overlay) overlay.remove();
        }
    }

    async function captureElement(el, scale = 2) {
        if (document.fonts && document.fonts.ready) {
            await document.fonts.ready;
        }
        const canvas = await html2canvas(el, {
            scale:           scale,
            useCORS:         true,
            allowTaint:      true,
            backgroundColor: '#ffffff',
            logging:         false,
            windowWidth:     el.scrollWidth,
            windowHeight:    el.scrollHeight
        });
        return canvas.toDataURL('image/jpeg', 0.92);
    }

    function addImageToPdf(pdf, imgData, x, y, imgW, imgH) {
        const pageH = PAGE_H - MARGIN * 2;
        let remainH = imgH;
        let srcY    = 0;

        while (remainH > 0) {
            const sliceH = Math.min(remainH, pageH - y + MARGIN);

            const tmpCanvas  = document.createElement('canvas');
            const tmpImg     = new Image();
            tmpImg.src       = imgData;
            
            if (y + sliceH > PAGE_H - MARGIN) {
                pdf.addPage();
                y = MARGIN;
            }

            pdf.addImage(imgData, 'JPEG', x, y, imgW, imgH);
            y += imgH + 6;
            break; 
        }
        return y;
    }

    async function downloadZonePdf(zoneId) {
        const data = getCurrentData();
        const zona = data.find(z => z.id == zoneId);

        if (!zona) {
            alert(`Zona ${zoneId} non trovata. Assicurati di aver pubblicato il bollettino.`);
            return;
        }

        toggleLoadingOverlay(true, `Generazione PDF — ${zona.nome}…`);

        try {
            const svgId = Object.entries(NOME_TO_CSS_VAR)
                .find(([nome]) => nome === zona.nome)?.[1] || null;

            const svgMarkup = buildMapSvgMarkup(svgId, data);
            const note = getCurrentNote();
            const html = buildZoneTemplate(zona, svgMarkup, note);

            const container = injectHiddenTemplate(html, 'pdf-zone-template');

            await new Promise(r => setTimeout(r, 300));

            const imgData = await captureElement(container, 2.5);

            const aspectRatio = container.scrollHeight / container.scrollWidth;
            const imgW  = CONTENT_W;
            const imgH  = imgW * aspectRatio;

            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

            let y = MARGIN;
            const pageContentH = PAGE_H - MARGIN * 2;

            if (imgH <= pageContentH) {
                pdf.addImage(imgData, 'JPEG', MARGIN, y, imgW, imgH);
            } else {
                await addMultiPageImage(pdf, imgData, container, imgW);
            }

            const filename = `bollettino_${zona.nome.replace(/\s+/g, '_')}_${formatDate()}.pdf`;
            pdf.save(filename);

        } catch (err) {
            console.error('[PdfGenerator] Errore generazione PDF zona:', err);
            alert('Errore nella generazione del PDF: ' + err.message);
        } finally {
            const tmpl = document.getElementById('pdf-zone-template');
            if (tmpl) tmpl.remove();
            toggleLoadingOverlay(false);
        }
    }

    async function downloadFullPdf() {
        toggleLoadingOverlay(true, 'Generazione PDF Completo…');

        try {
            const data = getCurrentData();
            const note = getCurrentNote();

            const svgMarkup = buildMapSvgMarkup(null, data);
            const html = buildFullTemplate(data, svgMarkup, note);

            const container = injectHiddenTemplate(html, 'pdf-full-template');

            await new Promise(r => setTimeout(r, 300));

            const imgData = await captureElement(container, 2.5);

            const aspectRatio = container.scrollHeight / container.scrollWidth;
            const imgW  = CONTENT_W;
            const imgH  = imgW * aspectRatio;

            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

            const pageContentH = PAGE_H - MARGIN * 2;

            if (imgH <= pageContentH) {
                pdf.addImage(imgData, 'JPEG', MARGIN, MARGIN, imgW, imgH);
            } else {
                await addMultiPageImage(pdf, imgData, container, imgW);
            }

            pdf.save(`bollettino_VDA_completo_${formatDate()}.pdf`);

        } catch (err) {
            console.error('[PdfGenerator] Errore generazione PDF completo:', err);
            alert('Errore nella generazione del PDF: ' + err.message);
        } finally {
            const tmpl = document.getElementById('pdf-full-template');
            if (tmpl) tmpl.remove();
            toggleLoadingOverlay(false);
        }
    }

    async function addMultiPageImage(pdf, imgData, srcEl, targetW) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const srcW   = img.naturalWidth;
                const srcH   = img.naturalHeight;
                const pxPerMm    = srcW / targetW;
                const pageHmm    = PAGE_H - MARGIN * 2;
                const pageHpx    = pageHmm * pxPerMm;
                let srcY         = 0;
                let isFirstPage  = true;

                while (srcY < srcH) {
                    const sliceHpx = Math.min(pageHpx, srcH - srcY);
                    const c  = document.createElement('canvas');
                    c.width  = srcW;
                    c.height = sliceHpx;
                    const ctx = c.getContext('2d');
                    ctx.drawImage(img, 0, srcY, srcW, sliceHpx, 0, 0, srcW, sliceHpx);
                    const sliceData = c.toDataURL('image/jpeg', 0.92);
                    const sliceHmm  = sliceHpx / pxPerMm;

                    if (!isFirstPage) pdf.addPage();
                    pdf.addImage(sliceData, 'JPEG', MARGIN, MARGIN, targetW, sliceHmm);

                    srcY        += sliceHpx;
                    isFirstPage  = false;
                }
                resolve();
            };
            img.onerror = reject;
            img.src = imgData;
        });
    }

    function formatDate() {
        const d = new Date();
        return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
    }

    function injectPdfButtons() {
        const isBollettino = !!document.getElementById('editor-panel');
        const isMappa      = !!document.querySelector('.mappa-container');

        if (isBollettino) {
            injectBollettinoButtons();
        }
        if (isMappa) {
            injectMappaButtons();
        }
    }

    function injectBollettinoButtons() {
    }

    function injectMappaButtons() {
        const mappaHeader = document.querySelector('.mappa-header');
        const container   = mappaHeader || document.querySelector('.mappa-box') || document.body;
        if (container) {
            const pdfBtn = document.createElement('button');
            pdfBtn.id = 'btn-pdf-completo-mappa';
            pdfBtn.style.cssText = `
                background:#1d4ed8;color:#fff;border:none;
                padding:8px 18px;border-radius:10px;font-weight:700;
                font-size:12px;cursor:pointer;transition:.2s;
                text-transform:uppercase;letter-spacing:.05em;
                box-shadow:0 2px 8px rgba(0,0,0,.3);
                align-self:center;white-space:nowrap;`;
            pdfBtn.textContent = '📄 PDF Completo';
            pdfBtn.addEventListener('mouseover', () => pdfBtn.style.background = '#1e40af');
            pdfBtn.addEventListener('mouseout',  () => pdfBtn.style.background = '#1d4ed8');
            pdfBtn.addEventListener('click', () => downloadFullPdf());
            container.appendChild(pdfBtn);
        }

        const tendina = document.getElementById('tendina');
        const contenutoEl = document.getElementById('contenutoTendina');

        // Fix Observer per l'aggiunta del pulsante anche passando da una zona all'altra
        if (tendina && contenutoEl) {
            const observer = new MutationObserver(() => {
                const isAperta  = tendina.classList.contains('aperta');
                let existingBtn = document.getElementById('btn-pdf-zona-mappa');

                if (isAperta && !existingBtn) {
                    const titoloEl = document.getElementById('titoloTendina');
                    if (contenutoEl) {
                        const pdfZonaBtn = document.createElement('button');
                        pdfZonaBtn.id = 'btn-pdf-zona-mappa';
                        pdfZonaBtn.style.cssText = `
                            background:#1d4ed8;color:#fff;border:none;
                            padding:8px 14px;border-radius:8px;font-weight:700;
                            font-size:11px;cursor:pointer;margin-top:14px;
                            display:block;width:100%;text-align:center;
                            transition:.2s;text-transform:uppercase;letter-spacing:.04em;`;
                        pdfZonaBtn.textContent = '📄 Scarica PDF Zona';
                        pdfZonaBtn.addEventListener('mouseover', () => pdfZonaBtn.style.background = '#1e40af');
                        pdfZonaBtn.addEventListener('mouseout',  () => pdfZonaBtn.style.background = '#1d4ed8');
                        pdfZonaBtn.addEventListener('click', () => {
                            const nomeTendina = titoloEl ? titoloEl.textContent.trim() : '';
                            const data = readBollettinoData();
                            const zona = data.find(z => z.nome === nomeTendina);
                            if (zona) {
                                downloadZonePdf(zona.id);
                            } else {
                                alert('Dati zona non trovati nel bollettino salvato.');
                            }
                        });
                        contenutoEl.appendChild(pdfZonaBtn);
                    }
                } else if (!isAperta && existingBtn) {
                    existingBtn.remove();
                }
            });
            // Ascolta sia i cambiamenti di classe della tendina sia il contenuto sovrascritto
            observer.observe(tendina, { attributes: true, attributeFilter: ['class'] });
            observer.observe(contenutoEl, { childList: true });
        }
    }

    function init() {
        if (typeof html2canvas === 'undefined') {
            console.error('[PdfGenerator] html2canvas non trovato! Aggiungi lo script nel <head>.');
            return;
        }
        if (typeof window.jspdf === 'undefined' && typeof jsPDF === 'undefined') {
            console.error('[PdfGenerator] jsPDF non trovato! Aggiungi lo script nel <head>.');
            return;
        }

        injectPdfButtons();
        console.log('[PdfGenerator] ✅ Inizializzato correttamente.');
    }

    return {
        init,
        downloadZonePdf,
        downloadFullPdf
    };

})();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => PdfGenerator.init());
} else {
    PdfGenerator.init();
}